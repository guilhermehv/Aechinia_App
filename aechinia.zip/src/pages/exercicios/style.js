import { StyleSheet } from 'react-native';
import Constants from 'expo-constants';

export default StyleSheet.create({
  containerT: {
    justifyContent: 'flex-start',
    flex: 1,
    backgroundColor: '#282828',
    alignItems: 'center',
},
video:{
  marginTop: 55,
}
});